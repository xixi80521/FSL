#!/usr/bin/env bash
set -euo pipefail

rm -rf logs_comm_smoke logs_comm_smoke_analysis

python train.py \
  --dataset toy \
  --model resnet18 \
  --baseline epafl \
  --partition_method hetero \
  --partition_alpha 0.5 \
  --client_number 2 \
  --frac 1.0 \
  --rounds 1 \
  --batch_size 8 \
  --toy_train_total 32 \
  --toy_test_total 16 \
  --activation_compression topk \
  --topk_ratio 0.1 \
  --target_accs 0.01 \
  --use_auto_profile true \
  --profile_warmup_batches 0 \
  --profile_measure_batches 1 \
  --eval_all_clients true \
  --enable_personalized_test false \
  --enable_system_profile false \
  --enable_energy_profile false \
  --seed 10 \
  --method_name COMM-SMOKE \
  --log_dir logs_comm_smoke

python analyze_communication_review.py \
  --log_root logs_comm_smoke \
  --out_dir logs_comm_smoke_analysis \
  --target_accuracy 0.01

python - <<'PYCODE'
import glob
import math
import pandas as pd

path = glob.glob("logs_comm_smoke/*-comm.csv")[0]
row = pd.read_csv(path).iloc[-1]

expected = sum(
    float(row.get(key, 0.0))
    for key in (
        "uplink_activation_compressed",
        "uplink_labels",
        "downlink_gradient",
        "uplink_client_backbone_params",
        "downlink_client_params",
    )
)
actual = float(row["round_total_bytes"])

assert math.isclose(actual, expected, rel_tol=0.0, abs_tol=1e-6), (
    actual,
    expected,
)
assert float(row["cum_total_bytes"]) == actual
assert "cum_raw_activation_reference_bytes" in row.index

print("[OK] exact transmitted-byte accounting smoke test passed")
print("comm_csv =", path)
PYCODE
