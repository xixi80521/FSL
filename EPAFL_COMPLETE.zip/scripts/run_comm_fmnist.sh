#!/usr/bin/env bash
set -euo pipefail

# Fashion-MNIST communication-review wrapper.
# Main setting:
#   model=resnet110
#   non-IID=Dirichlet label skew, alpha=0.5
#   clients=10
#   main participation=1.0 (100%)
#   rounds=200
#   seeds=10 20 30 40 50
#   target_accuracy=0.80

GROUP="${1:-}"
if [[ -z "$GROUP" ]]; then
  echo "Usage: bash scripts/run_comm_fmnist.sh {epafl_compression|baseline_none|baseline_preferred|participation_preferred}" >&2
  exit 2
fi

MODEL="${MODEL:-resnet110}" DATASET="fmnist" PARTITION="${PARTITION:-hetero}" ALPHA="${ALPHA:-0.5}" CLIENTS="${CLIENTS:-10}" FRAC="${FRAC:-1.0}" BATCH="${BATCH:-64}" ROUNDS="${ROUNDS:-200}" CLIENT_EPOCH="${CLIENT_EPOCH:-1}" SEEDS="${SEEDS:-10 20 30 40 50}" TARGET_ACC="${TARGET_ACC:-0.80}" FIXED_TIER="${FIXED_TIER:-6}" LOGROOT="${LOGROOT:-logs_communication_review/fmnist}" PREFERRED_COMP="${PREFERRED_COMP:-int8}" PREFERRED_TOPK="${PREFERRED_TOPK:-0.1}" bash scripts/run_communication_review.sh "$GROUP"
