#!/usr/bin/env bash
set -euo pipefail

GROUP="${1:-}"
if [[ -z "$GROUP" ]]; then
  echo "Usage: bash scripts/run_communication_review.sh {epafl_compression|baseline_none|baseline_preferred|participation_preferred}" >&2
  exit 2
fi

MODEL="${MODEL:-resnet110}"
DATASET="${DATASET:-cifar10}"
PARTITION="${PARTITION:-hetero}"
ALPHA="${ALPHA:-0.5}"
CLIENTS="${CLIENTS:-10}"
FRAC="${FRAC:-1.0}"
BATCH="${BATCH:-64}"
ROUNDS="${ROUNDS:-200}"
CLIENT_EPOCH="${CLIENT_EPOCH:-1}"
SEEDS="${SEEDS:-10 20 30 40 50}"
TARGET_ACC="${TARGET_ACC:-0.60}"
FIXED_TIER="${FIXED_TIER:-6}"
BASELINES="${BASELINES:-splitfed lglsfl static_tier dtfl esfl dsfl epafl}"
PREFERRED_COMP="${PREFERRED_COMP:-int8}"
PREFERRED_TOPK="${PREFERRED_TOPK:-0.1}"
PARTICIPATION_LEVELS="${PARTICIPATION_LEVELS:-1.0 0.8 0.5}"
LOGROOT="${LOGROOT:-logs_communication_review/${DATASET}}"
DRY_RUN="${DRY_RUN:-0}"

case "$DATASET" in
  cifar10|fmnist|mnist) ;;
  *)
    echo "Invalid DATASET=$DATASET. Use cifar10, fmnist, or mnist." >&2
    exit 2
    ;;
esac

python -c "f=float('$FRAC'); a=float('$ALPHA'); n=int('$CLIENTS'); assert 0 < f <= 1; assert a > 0; assert n > 0"

mkdir -p "$LOGROOT"

run_one() {
  local method="$1"
  local seed="$2"
  local comp="$3"
  local ratio="$4"
  local frac="$5"

  local compression_tag="$comp"
  if [[ "$comp" == "topk" ]]; then
    compression_tag="topk${ratio//./}"
  fi

  local frac_tag="${frac//./p}"
  local name="COMM-${method}-${MODEL}-${DATASET}-${PARTITION}-a${ALPHA}-N${CLIENTS}-f${frac_tag}-${compression_tag}-s${seed}"
  local out="${LOGROOT}/${GROUP}/${name}"
  mkdir -p "$out"

  echo "========================================================================"
  echo "RUN: $name"
  echo "dataset=$DATASET"
  echo "model=$MODEL"
  echo "heterogeneity=$PARTITION"
  echo "dirichlet_alpha=$ALPHA"
  echo "clients=$CLIENTS"
  echo "participation_fraction=$frac"
  echo "compression=$comp"
  echo "topk_ratio=$ratio"
  echo "seed=$seed"
  echo "target_accuracy=$TARGET_ACC"
  echo "========================================================================"

  cmd=(
    python train.py
    --baseline "$method"
    --method_name "$name"
    --model "$MODEL"
    --dataset "$DATASET"
    --partition_method "$PARTITION"
    --partition_alpha "$ALPHA"
    --client_number "$CLIENTS"
    --frac "$frac"
    --batch_size "$BATCH"
    --client_epoch "$CLIENT_EPOCH"
    --rounds "$ROUNDS"
    --fixed_tier "$FIXED_TIER"
    --activation_compression "$comp"
    --topk_ratio "$ratio"
    --target_accs "$TARGET_ACC"
    --use_auto_profile true
    --eval_all_clients true
    --enable_personalized_test false
    --enable_system_profile true
    --enable_energy_profile true
    --seed "$seed"
    --log_dir "$out"
  )

  if [[ "$DRY_RUN" == "1" ]]; then
    printf 'DRY_RUN command:'
    printf ' %q' "${cmd[@]}"
    printf '\n'
  else
    "${cmd[@]}"
  fi
}

case "$GROUP" in
  epafl_compression)
    for seed in $SEEDS; do
      run_one epafl "$seed" none 1.0 "$FRAC"
      run_one epafl "$seed" fp16 1.0 "$FRAC"
      run_one epafl "$seed" int8 1.0 "$FRAC"
      for ratio in 0.5 0.2 0.1; do
        run_one epafl "$seed" topk "$ratio" "$FRAC"
      done
    done
    ;;

  baseline_none)
    for seed in $SEEDS; do
      for method in $BASELINES; do
        run_one "$method" "$seed" none 1.0 "$FRAC"
      done
    done
    ;;

  baseline_preferred)
    preferred_ratio=1.0
    if [[ "$PREFERRED_COMP" == "topk" ]]; then
      preferred_ratio="$PREFERRED_TOPK"
    fi
    for seed in $SEEDS; do
      for method in $BASELINES; do
        run_one "$method" "$seed" "$PREFERRED_COMP" "$preferred_ratio" "$FRAC"
      done
    done
    ;;

  participation_preferred)
    preferred_ratio=1.0
    if [[ "$PREFERRED_COMP" == "topk" ]]; then
      preferred_ratio="$PREFERRED_TOPK"
    fi
    for frac in $PARTICIPATION_LEVELS; do
      for seed in $SEEDS; do
        run_one epafl "$seed" "$PREFERRED_COMP" "$preferred_ratio" "$frac"
      done
    done
    ;;

  *)
    echo "Unknown group=$GROUP" >&2
    exit 2
    ;;
esac

echo "[DONE] $DATASET / $GROUP"
