#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
preflight

# Reviewer purpose: synthetic feature/domain shift.
# The review-ready patch ensures personalized held-out evaluation inherits each
# client's deterministic rotation domain as well as its local label profile.
seed="${SEED:-10}"
ROOT="${LOG_BASE}/07_feature_skew_mnist_n20"
base_args mnist 0.1 20 1.0 "${ROUNDS:-200}" "${seed}"
set_arg BASE_ARGS --partition_method feature_skew
run_train "REV-HET-EPAFL-R18-MNIST-FEATURE-ROT-N20-S${seed}" \
  "${ROOT}/seed${seed}" --baseline epafl "${BASE_ARGS[@]}"

run_controlled_analysis "${ROOT}" "${ANALYSIS_BASE}/07_feature_skew_mnist_n20"
