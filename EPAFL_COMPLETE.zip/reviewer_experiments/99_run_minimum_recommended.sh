#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Minimum high-value package. This intentionally does NOT run every optional
# reviewer experiment. Run individual scripts when you want finer control.
bash "${SCRIPT_DIR}/00_preflight.sh"
bash "${SCRIPT_DIR}/01_core_multiseed_epafl_vs_dtfl.sh"
bash "${SCRIPT_DIR}/02_scalability_n100.sh"
bash "${SCRIPT_DIR}/03_partial_participation_pair.sh"
bash "${SCRIPT_DIR}/04_network_stress.sh"
bash "${SCRIPT_DIR}/05_pathological_label_skew.sh"
bash "${SCRIPT_DIR}/06_quantity_skew.sh"
bash "${SCRIPT_DIR}/07_feature_skew.sh"
bash "${SCRIPT_DIR}/09_compressed_direct_baselines.sh"

echo "Minimum recommended reviewer experiment package completed."
echo "Optional safeguard experiment: bash reviewer_experiments/08_affinity_safeguard.sh"
