#!/usr/bin/env bash
set -Eeuo pipefail

# Shared runner for reviewer experiments.
# Every individual experiment script sources this file.

LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXP_DIR="$(cd "${LIB_DIR}/.." && pwd)"
PROJECT_ROOT="$(cd "${EXP_DIR}/.." && pwd)"
cd "${PROJECT_ROOT}"

PYTHON_BIN="${PYTHON_BIN:-python}"
GPU_ID="${GPU_ID:-0}"
export CUDA_VISIBLE_DEVICES="${GPU_ID}"
export PYTHONUNBUFFERED=1

LOG_BASE="${LOG_BASE:-${PROJECT_ROOT}/logs_reviewer_revision}"
ANALYSIS_BASE="${ANALYSIS_BASE:-${PROJECT_ROOT}/analysis_reviewer_revision}"

FORCE="${FORCE:-0}"
DRY_RUN="${DRY_RUN:-0}"
SMOKE="${SMOKE:-0}"
REQUIRE_CUDA="${REQUIRE_CUDA:-1}"
ANALYZE_AFTER="${ANALYZE_AFTER:-1}"

mkdir -p "${LOG_BASE}" "${ANALYSIS_BASE}"

ts() { date '+%Y-%m-%d %H:%M:%S'; }
info() { printf '[%s] [INFO] %s\n' "$(ts)" "$*"; }
warn() { printf '[%s] [WARN] %s\n' "$(ts)" "$*" >&2; }
die() { printf '[%s] [ERROR] %s\n' "$(ts)" "$*" >&2; exit 2; }

quote_cmd() {
  local out="" q
  for q in "$@"; do
    printf -v q '%q' "$q"
    out+="${q} "
  done
  printf '%s\n' "${out% }"
}

set_arg() {
  # set_arg ARRAY_NAME --flag value
  local -n _arr="$1"
  local flag="$2"
  local value="$3"
  local i
  for ((i=0; i<${#_arr[@]}; i++)); do
    if [[ "${_arr[$i]}" == "${flag}" ]]; then
      if (( i + 1 >= ${#_arr[@]} )); then
        die "Malformed argument array: ${flag} has no value"
      fi
      _arr[$((i+1))]="${value}"
      return 0
    fi
  done
  _arr+=("${flag}" "${value}")
}


require_project() {
  [[ -f "${PROJECT_ROOT}/train.py" ]] || die "train.py not found at ${PROJECT_ROOT}"
  [[ -f "${PROJECT_ROOT}/model/resnet18.py" ]] || die "model/resnet18.py not found"
  [[ -f "${PROJECT_ROOT}/utils/reviewer_metrics.py" ]] || die "reviewer utilities not found"
}

preflight() {
  if [[ "${SKIP_PREFLIGHT:-0}" == "1" ]]; then
    require_project
    info "SKIP_PREFLIGHT=1; skipping dependency/GPU/unit-test preflight."
    return 0
  fi
  require_project
  "${PYTHON_BIN}" - <<'PY'
import importlib, sys
mods = ["torch","torchvision","numpy","pandas","sklearn","psutil"]
missing=[]
for m in mods:
    try: importlib.import_module(m)
    except Exception as e: missing.append((m,str(e)))
if missing:
    raise SystemExit("Missing/broken Python packages: " + repr(missing))
import torch
print("[PREFLIGHT] Python:", sys.version.split()[0])
print("[PREFLIGHT] Torch:", torch.__version__)
print("[PREFLIGHT] CUDA available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print("[PREFLIGHT] CUDA device:", torch.cuda.get_device_name(0))
PY

  if [[ "${REQUIRE_CUDA}" == "1" ]]; then
    "${PYTHON_BIN}" - <<'PY'
import torch
if not torch.cuda.is_available():
    raise SystemExit("CUDA is required for the formal reviewer runs. Set REQUIRE_CUDA=0 only intentionally.")
PY
  fi

  # Parse every train.py argument once; catches syntax/import breakage before a long run.
  "${PYTHON_BIN}" train.py --help >/dev/null

  # Fast architecture test; no dataset download.
  "${PYTHON_BIN}" -m unittest tests.test_resnet18_split -v

  mkdir -p "${LOG_BASE}/_environment"
  {
    echo "timestamp=$(ts)"
    echo "project_root=${PROJECT_ROOT}"
    echo "python_bin=$(${PYTHON_BIN} -c 'import sys; print(sys.executable)')"
    echo "cuda_visible_devices=${CUDA_VISIBLE_DEVICES}"
    if command -v git >/dev/null 2>&1 && git rev-parse HEAD >/dev/null 2>&1; then
      echo "git_commit=$(git rev-parse HEAD)"
    else
      echo "git_commit=UNAVAILABLE_ZIP_OR_NON_GIT_TREE"
    fi
  } > "${LOG_BASE}/_environment/runner_environment.txt"

  "${PYTHON_BIN}" -m pip freeze > "${LOG_BASE}/_environment/pip_freeze.txt" || true
  if command -v nvidia-smi >/dev/null 2>&1; then
    nvidia-smi > "${LOG_BASE}/_environment/nvidia_smi.txt" || true
  fi

  "${PYTHON_BIN}" "${EXP_DIR}/preflight_profile.py" \
    --out "${LOG_BASE}/_environment/system_profiler_snapshot.json"
}

smoke_rewrite_args() {
  # Usage: smoke_rewrite_args array_name
  local -n _a="$1"
  [[ "${SMOKE}" == "1" ]] || return 0
  local i
  for ((i=0; i<${#_a[@]}; i++)); do
    case "${_a[$i]}" in
      --rounds) _a[$((i+1))]="${SMOKE_ROUNDS:-2}" ;;
      --client_number) _a[$((i+1))]="${SMOKE_CLIENTS:-4}" ;;
      --personalized_test_samples) _a[$((i+1))]="${SMOKE_PERSONALIZED_SAMPLES:-40}" ;;
      --profile_warmup_batches) _a[$((i+1))]="1" ;;
      --profile_measure_batches) _a[$((i+1))]="1" ;;
      --eval_every) _a[$((i+1))]="1" ;;
      --eval_personalized_every) _a[$((i+1))]="1" ;;
    esac
  done
}

prepare_out_dir() {
  local out="$1"
  if [[ -f "${out}/.completed" && "${FORCE}" != "1" ]]; then
    info "Already completed, skipping: ${out}"
    return 10
  fi
  if [[ -d "${out}" && -n "$(find "${out}" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
    if [[ "${FORCE}" == "1" ]]; then
      local backup="${out}.bak-$(date '+%Y%m%d-%H%M%S')"
      warn "FORCE=1: moving old run directory to ${backup}"
      mv "${out}" "${backup}"
    else
      die "Run directory exists but is not marked complete: ${out}. Inspect it, or rerun with FORCE=1."
    fi
  fi
  mkdir -p "${out}"
  return 0
}

run_train() {
  local run_name="$1"
  local out="$2"
  shift 2
  local args=("$@")
  smoke_rewrite_args args

  if [[ "${SMOKE}" == "1" ]]; then
    run_name="SMOKE-${run_name}"
    out="${out}__SMOKE"
  fi

  mkdir -p "$(dirname "${out}")"
  local cmd=("${PYTHON_BIN}" -u train.py "${args[@]}" --method_name "${run_name}" --log_dir "${out}")
  info "Experiment: ${run_name}"
  info "Output: ${out}"
  printf '%s\n' "$(quote_cmd "${cmd[@]}")" | tee "${out}.planned_command.txt"

  if [[ "${DRY_RUN}" == "1" ]]; then
    info "DRY_RUN=1; command not executed."
    return 0
  fi

  prepare_out_dir "${out}" || {
    local rc=$?
    [[ "${rc}" == "10" ]] && return 0
    return "${rc}"
  }

  printf '%s\n' "$(quote_cmd "${cmd[@]}")" > "${out}/command.txt"
  {
    echo "started_at=$(ts)"
    echo "run_name=${run_name}"
    echo "project_root=${PROJECT_ROOT}"
    echo "gpu_id=${GPU_ID}"
  } > "${out}/runner_manifest.txt"

  set +e
  "${cmd[@]}" 2>&1 | tee "${out}/console.log"
  local rc=${PIPESTATUS[0]}
  set -e
  if [[ "${rc}" != "0" ]]; then
    echo "failed_at=$(ts)" >> "${out}/runner_manifest.txt"
    echo "exit_code=${rc}" >> "${out}/runner_manifest.txt"
    die "Training failed for ${run_name}; inspect ${out}/console.log"
  fi

  "${PYTHON_BIN}" "${EXP_DIR}/validate_run.py" --log-dir "${out}" --expect-model resnet18

  echo "completed_at=$(ts)" >> "${out}/runner_manifest.txt"
  touch "${out}/.completed"
  info "Completed: ${run_name}"
}

run_controlled_analysis() {
  local log_root="$1"
  local out_dir="$2"
  [[ "${DRY_RUN}" == "1" || "${ANALYZE_AFTER}" != "1" ]] && return 0
  mkdir -p "${out_dir}"
  "${PYTHON_BIN}" analyze_reviewer_controlled.py --log_root "${log_root}" --out_dir "${out_dir}"
}

run_partial_analysis() {
  local log_root="$1"
  local out_dir="$2"
  [[ "${DRY_RUN}" == "1" || "${ANALYZE_AFTER}" != "1" ]] && return 0
  mkdir -p "${out_dir}"
  "${PYTHON_BIN}" analyze_partial_participation.py \
    --log_root "${log_root}" --out_dir "${out_dir}" --reference_method epafl
}

run_comm_analysis() {
  local log_root="$1"
  local out_dir="$2"
  local target="$3"
  [[ "${DRY_RUN}" == "1" || "${ANALYZE_AFTER}" != "1" ]] && return 0
  mkdir -p "${out_dir}"
  "${PYTHON_BIN}" analyze_communication_review.py \
    --log_root "${log_root}" --out_dir "${out_dir}" --target_accuracy "${target}"
}

# Stable common ResNet18 reviewer settings.
base_args() {
  local dataset="$1" alpha="$2" clients="$3" frac="$4" rounds="$5" seed="$6"
  BASE_ARGS=(
    --model resnet18
    --dataset "${dataset}"
    --data_dir ./data
    --partition_method hetero
    --partition_alpha "${alpha}"
    --client_number "${clients}"
    --frac "${frac}"
    --participation_seed "${seed}"
    --participation_policy uniform
    --freeze_nonparticipants true
    --deterministic_client_rng true
    --batch_size 64
    --client_epoch 1
    --rounds "${rounds}"
    --lr 0.001
    --use_auto_profile true
    --profile_warmup_batches 2
    --profile_measure_batches 5
    --activation_compression none
    --bandwidth_trace static
    --evaluation_mode all
    --eval_every 5
    --enable_personalized_test true
    --personalized_test_samples 200
    --eval_personalized_every 5
    --enable_system_profile true
    --enable_energy_profile true
    --state_storage_device cpu
    --server_worker_count 8
    --target_accs "0.3,0.4,0.5,0.6,0.7,0.8,0.9"
    --log_reviewer_diagnostics true
    --seed "${seed}"
  )
}
