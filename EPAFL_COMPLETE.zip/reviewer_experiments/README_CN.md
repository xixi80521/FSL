# EPAFL ResNet18 Reviewer Experiments — 直接运行说明

本目录用于本轮审稿意见的补充实验。所有正式脚本默认：
- ResNet18；
- Linux/CUDA；
- `state_storage_device=cpu`；
- `server_worker_count=8` 仅作为**建模 queue diagnostic**，不声称物理 8-worker 并发；
- 保存实际 command、console log、run_config、代码 SHA-256 fingerprint；
- 训练成功后自动检查 CSV 结构，防止通信日志列错位；
- 默认日志：`logs_reviewer_revision/`；
- 默认分析：`analysis_reviewer_revision/`。

## 先做一次环境检查

```bash
bash reviewer_experiments/00_preflight.sh
```

如果机器没有 CUDA，只是想做语法/小型 CPU 测试：

```bash
REQUIRE_CUDA=0 SMOKE=1 bash reviewer_experiments/00_preflight.sh
```

## 推荐的正式实验

### 1. EPAFL vs DTFL 三个 seed（主结论唯一建议重复的实验）

```bash
bash reviewer_experiments/01_core_multiseed_epafl_vs_dtfl.sh
```

默认 seeds：10/20/30。

若 seed10 已确认来自**完全相同 code fingerprint**，只补两个 seed：

```bash
SEEDS="20 30" bash reviewer_experiments/01_core_multiseed_epafl_vs_dtfl.sh
```

### 2. N=100 scalability

```bash
bash reviewer_experiments/02_scalability_n100.sh
```

### 3. N=20 full vs 50% partial participation

```bash
bash reviewer_experiments/03_partial_participation_pair.sh
```

### 4. Static / severe bursty / constrained network

```bash
bash reviewer_experiments/04_network_stress.sh
```

如果 static 已由此版本代码运行过并且你只想补两个 stress trace：

```bash
INCLUDE_STATIC=0 bash reviewer_experiments/04_network_stress.sh
```

注意：这里是 bandwidth trace emulation，不是 `tc/netem` packet loss/outage。

### 5. Pathological label skew

```bash
bash reviewer_experiments/05_pathological_label_skew.sh
```

### 6. Quantity skew (log-normal sigma=2.0)

```bash
bash reviewer_experiments/06_quantity_skew.sh
```

### 7. Synthetic feature/domain skew (0/90/180/270° rotations)

```bash
bash reviewer_experiments/07_feature_skew.sh
```

Review-ready 代码已修复 personalized test：feature-skew 时会继承每个客户端的旋转域，而不仅仅匹配标签比例。

### 8. Self-weight / hybrid safeguard

```bash
bash reviewer_experiments/08_affinity_safeguard.sh
```

默认比较：
- complementarity + self weight 0.05；
- complementarity + self weight 0.20；
- hybrid gamma 0.5。

如还要 similarity：

```bash
INCLUDE_SIMILARITY=1 bash reviewer_experiments/08_affinity_safeguard.sh
```

### 9. Preferred Top-k0.1 direct baselines

```bash
bash reviewer_experiments/09_compressed_direct_baselines.sh
```

默认重新跑：
- DTFL + Top-k0.1
- SplitFed + Top-k0.1
- EPAFL + Top-k0.1

若 EPAFL Top-k0.1 已确认由完全相同代码生成：

```bash
INCLUDE_EPAFL=0 bash reviewer_experiments/09_compressed_direct_baselines.sh
```

### 10. Mild network fluctuation（可选）

```bash
bash reviewer_experiments/10_network_mild_optional.sh
```

## 一次跑最低推荐组合

```bash
bash reviewer_experiments/99_run_minimum_recommended.sh
```

考虑运行时间，实际更建议你**逐个 bash**，每跑完一个先检查 analysis 输出。

---

# 安全运行模式

## 只打印命令，不训练

```bash
DRY_RUN=1 bash reviewer_experiments/04_network_stress.sh
```

## 超小 smoke test

`SMOKE=1` 会自动把 client 数降到 4、rounds 降到 2，并减少 profiler/test 样本：

```bash
SMOKE=1 bash reviewer_experiments/05_pathological_label_skew.sh
```

这只验证程序链路，不是论文数据。

## 指定 GPU

```bash
GPU_ID=1 bash reviewer_experiments/02_scalability_n100.sh
```

注意：正式数据尽量全部固定同一 GPU。

## 覆盖默认轮数

```bash
ROUNDS=100 bash reviewer_experiments/07_feature_skew.sh
```

正式论文建议仍采用脚本默认轮数，除非你在方法中明确写明。

## 已完成实验重跑

脚本成功后会生成 `.completed`。默认不会误覆盖。

重跑：

```bash
FORCE=1 bash reviewer_experiments/04_network_stress.sh
```

旧目录会自动备份为 `.bak-YYYYMMDD-HHMMSS`，不会直接删除。

---

# 这版代码顺手修复的两个关键问题

## 1. `comm.csv` 动态 tier 列导致 CSV 列错位

旧 `CommLedger` 第一轮直接写 header，但后续某个新 tier 第一次出现时会新增
`tier-specific` 列；使用 pandas append 会造成“新行列数 != 第一行 header”的 malformed CSV。

Review-ready 版本保存 round ledger 时用所有已观察 row 的列并集重写 CSV。
`comm_clients.csv` 保持稳定 append。

因此新实验的：
- `comm.csv`
- `comm_clients.csv`
- `target_acc.csv`

可以作为重新核对论文通信数字的统一 source of truth。

## 2. Feature-skew personalized held-out domain

旧 personalized test 只从 global benchmark test set 根据 P(y) 抽样。
这样 feature-skew 客户端训练在 90°/180°/270° 域，却仍可能在 0° global domain 测试。

Review-ready 版本在 `partition_method=feature_skew` 时，personalized held-out
subset 从该客户端自己的 transformed test dataset 中抽取，因此同时匹配：
- local label profile；
- client feature/domain transform。

---

# 当前仍不能用这些脚本声称已经完成的项目

这些实验需要训练架构进一步改造，不能通过改命令名称“模拟完成”：

1. 真实多节点 / 独立物理客户端；
2. `tc/netem` 真正 delay/jitter/packet loss/outage（当前 activation 不通过真实 socket）；
3. 物理 server multi-worker GPU queue（当前 `server_worker_count` 是 modeled replay）；
4. random/capability-correlated client failure + recovery；
5. late-arriving clients；
6. profile misclassification stress；
7. EWMA / moving average / oracle estimator baseline；
8. auxiliary-vs-end-to-end gradient alignment；
9. optimizer-state migration overhead。

论文中要继续把当前系统证据限定为：
**controlled single-host heterogeneous-client emulation with measured host execution/resource counters and modeled network/server effects**。
