#!/usr/bin/env python3
import argparse, csv, glob, json, math, os, sys
import pandas as pd

p=argparse.ArgumentParser()
p.add_argument("--log-dir", required=True)
p.add_argument("--expect-model", default="resnet18")
a=p.parse_args()

root=os.path.abspath(a.log_dir)
cfgs=sorted(glob.glob(os.path.join(root, "*-run_config.json")))
if not cfgs:
    raise SystemExit(f"[VALIDATE] no *-run_config.json in {root}")
cfg_path=cfgs[-1]
with open(cfg_path, encoding="utf-8") as f:
    cfg=json.load(f)

errors=[]
warnings=[]

if cfg.get("model") != a.expect_model:
    errors.append(f"model={cfg.get('model')} expected={a.expect_model}")
if cfg.get("execution_model") != "sequential_single_process_virtual_clients":
    warnings.append(f"unexpected execution_model={cfg.get('execution_model')}")
if not cfg.get("git_commit") and not cfg.get("code_fingerprint_sha256"):
    errors.append("neither git_commit nor code_fingerprint_sha256 is recorded")
if not cfg.get("code_fingerprint_sha256"):
    warnings.append("code_fingerprint_sha256 missing (old code?)")

required_suffixes=[
    "-timing.csv","-comm.csv","-comm_clients.csv","-system.csv",
    "-scalability.csv","-heterogeneity.csv","-tier_profile.csv",
    "-scheduling.csv","-tier_groups.csv","-tier_occupancy.csv",
    "-aggregation_breakdown.csv","-server_jobs.csv","-metadata.json",
]
for suffix in required_suffixes:
    paths=glob.glob(os.path.join(root, f"*{suffix}"))
    if not paths:
        errors.append(f"missing {suffix}")
    elif all(os.path.getsize(x)==0 for x in paths):
        errors.append(f"empty {suffix}")

# Main accuracy CSV and client metrics are expected only when evaluation is enabled.
if cfg.get("evaluation_mode") != "none":
    csvs=glob.glob(os.path.join(root, "*.csv"))
    main=[]
    known_suffixes=tuple(required_suffixes[:-1])+(
        "-client_metrics.csv","-perclass.csv","-target_acc.csv","-dynamics.csv"
    )
    for x in csvs:
        b=os.path.basename(x)
        if not any(b.endswith(s) for s in known_suffixes):
            main.append(x)
    if not main:
        errors.append("main round-metrics CSV missing")
    if not glob.glob(os.path.join(root, "*-client_metrics.csv")):
        errors.append("client_metrics CSV missing")

# CSV structural integrity: every data row must have exactly header column count.
for path in sorted(glob.glob(os.path.join(root, "*.csv"))):
    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            rows=list(csv.reader(f))
        if not rows:
            continue
        width=len(rows[0])
        bad=[i+1 for i,r in enumerate(rows[1:], start=1) if len(r)!=width]
        if bad:
            errors.append(f"{os.path.basename(path)} malformed rows={bad[:8]} header_width={width}")
    except Exception as e:
        errors.append(f"cannot parse {os.path.basename(path)}: {e}")

# Profiling coverage is a warning, not a structural failure.
systems=sorted(glob.glob(os.path.join(root, "*-system.csv")))
if systems:
    try:
        df=pd.read_csv(systems[-1])
        for col in ("cpu_percent","process_rss_MB","gpu_util_percent","gpu_mem_allocated_MB"):
            if col not in df:
                warnings.append(f"system field missing: {col}")
            else:
                cov=float(df[col].notna().mean()) if len(df) else 0.0
                if cov < 0.5:
                    warnings.append(f"{col} coverage only {cov:.1%}")
    except Exception as e:
        warnings.append(f"system coverage check failed: {e}")

print("[VALIDATE] config:", cfg_path)
print("[VALIDATE] model:", cfg.get("model"), "baseline:", cfg.get("baseline"),
      "seed:", cfg.get("seed"), "rounds:", cfg.get("rounds"))
print("[VALIDATE] code fingerprint:", cfg.get("code_fingerprint_sha256"))
for w in warnings:
    print("[VALIDATE][WARN]", w)
if errors:
    for e in errors:
        print("[VALIDATE][ERROR]", e)
    raise SystemExit(3)
print("[VALIDATE] PASS:", root)
