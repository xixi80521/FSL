#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
preflight

# Reviewer purpose:
# strict paired N=20 full-vs-50%-participation comparison. Only frac changes.
seed="${SEED:-10}"
ROOT="${LOG_BASE}/03_partial_pair_mnist_a08_n20"

for frac in 1.0 0.5; do
  base_args mnist 0.8 20 "${frac}" "${ROUNDS:-200}" "${seed}"
  set_arg BASE_ARGS --eval_every 5
  set_arg BASE_ARGS --eval_personalized_every 5
  tag="$("${PYTHON_BIN}" - <<PY
f=float("${frac}")
print(f"F{int(round(f*100)):03d}")
PY
)"
  name="REV-PART-EPAFL-R18-MNIST-A08-N20-${tag}-S${seed}"
  out="${ROOT}/${tag}/seed${seed}"
  run_train "${name}" "${out}" --baseline epafl "${BASE_ARGS[@]}"
done

run_controlled_analysis "${ROOT}" "${ANALYSIS_BASE}/03_partial_pair_mnist_a08_n20"
run_partial_analysis "${ROOT}" "${ANALYSIS_BASE}/03_partial_pair_mnist_a08_n20/partial"
