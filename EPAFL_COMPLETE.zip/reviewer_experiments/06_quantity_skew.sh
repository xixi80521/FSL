#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
preflight

# Reviewer purpose: strong local-data-volume heterogeneity.
seed="${SEED:-10}"
ROOT="${LOG_BASE}/06_quantity_skew_mnist_n20"
base_args mnist 0.1 20 1.0 "${ROUNDS:-200}" "${seed}"
set_arg BASE_ARGS --partition_method quantity_skew
set_arg BASE_ARGS --quantity_skew_sigma 2.0
run_train "REV-HET-EPAFL-R18-MNIST-QTY-SIGMA2-N20-S${seed}" \
  "${ROOT}/seed${seed}" --baseline epafl "${BASE_ARGS[@]}"

run_controlled_analysis "${ROOT}" "${ANALYSIS_BASE}/06_quantity_skew_mnist_n20"
