#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
preflight

# Reviewer purpose:
# test the requested self-weight floor and hybrid similarity/complementarity safeguard.
# The base control is rerun on the same frozen code for an apples-to-apples comparison.
seed="${SEED:-10}"
ROOT="${LOG_BASE}/08_affinity_safeguard_mnist_a01_n20"

run_variant () {
  local tag="$1"; shift
  base_args mnist 0.1 20 1.0 "${ROUNDS:-200}" "${seed}"
  local extra=("$@")
  local j
  for ((j=0; j<${#extra[@]}; j+=2)); do
    set_arg BASE_ARGS "${extra[$j]}" "${extra[$((j+1))]}"
  done
  run_train "REV-AFF-EPAFL-R18-MNIST-A01-${tag}-S${seed}" \
    "${ROOT}/${tag}/seed${seed}" --baseline epafl "${BASE_ARGS[@]}"
}

run_variant "COMP-SELF005" --agg_strategy complementarity --affinity_self_weight 0.05
run_variant "COMP-SELF020" --agg_strategy complementarity --affinity_self_weight 0.20
run_variant "HYBRID-G050"  --agg_strategy hybrid --hybrid_gamma 0.50 --affinity_self_weight 0.05

if [[ "${INCLUDE_SIMILARITY:-0}" == "1" ]]; then
  run_variant "SIMILARITY" --agg_strategy similarity --affinity_self_weight 0.05
fi

run_controlled_analysis "${ROOT}" "${ANALYSIS_BASE}/08_affinity_safeguard_mnist_a01_n20"
