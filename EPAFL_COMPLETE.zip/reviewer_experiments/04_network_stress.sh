#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
preflight

# Reviewer purpose:
# stable vs severe fluctuating/bursty congestion vs bandwidth-constrained.
# These are bandwidth-emulation traces, NOT packet-loss/jitter/netem measurements.
seed="${SEED:-10}"
ROOT="${LOG_BASE}/04_network_stress_mnist_a03_n20"

# 1) clean static control on the exact same code version.
if [[ "${INCLUDE_STATIC:-1}" == "1" ]]; then
  base_args mnist 0.3 20 1.0 "${ROUNDS:-200}" "${seed}"
  set_arg BASE_ARGS --eval_every 1
  run_train "REV-NET-EPAFL-R18-MNIST-A03-STATIC-S${seed}" \
    "${ROOT}/static/seed${seed}" --baseline epafl "${BASE_ARGS[@]}"
fi

# 2) severe stochastic fluctuation + burst congestion.
base_args mnist 0.3 20 1.0 "${ROUNDS:-200}" "${seed}"
set_arg BASE_ARGS --bandwidth_trace fluctuating
set_arg BASE_ARGS --bw_jitter_sigma 0.30
set_arg BASE_ARGS --bw_congestion_prob 0.10
set_arg BASE_ARGS --bw_congestion_factor 12
set_arg BASE_ARGS --eval_every 1
run_train "REV-NET-EPAFL-R18-MNIST-A03-BURSTY-S${seed}" \
  "${ROOT}/bursty/seed${seed}" --baseline epafl "${BASE_ARGS[@]}"

# 3) constrained but stable bandwidth: each of the five profiles is 5x slower.
base_args mnist 0.3 20 1.0 "${ROUNDS:-200}" "${seed}"
set_arg BASE_ARGS --net_speed_list "20,6,6,6,2"
set_arg BASE_ARGS --eval_every 1
run_train "REV-NET-EPAFL-R18-MNIST-A03-CONSTRAINED-S${seed}" \
  "${ROOT}/constrained/seed${seed}" --baseline epafl "${BASE_ARGS[@]}"

run_controlled_analysis "${ROOT}" "${ANALYSIS_BASE}/04_network_stress_mnist_a03_n20"
