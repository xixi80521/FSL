#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
preflight

# Reviewer purpose:
# apply the preferred Top-k 0.1 setting to direct controlled FSL baselines.
# By default EPAFL is also rerun so all three methods use the identical code tree.
seed="${SEED:-10}"
ROOT="${LOG_BASE}/09_compressed_baselines_mnist_a03_n20_topk01"

METHODS=(dtfl splitfed)
if [[ "${INCLUDE_EPAFL:-1}" == "1" ]]; then
  METHODS+=(epafl)
fi

for method in "${METHODS[@]}"; do
  base_args mnist 0.3 20 1.0 "${ROUNDS:-200}" "${seed}"
  set_arg BASE_ARGS --activation_compression topk
  set_arg BASE_ARGS --topk_ratio 0.1
  set_arg BASE_ARGS --eval_every 1
  name="REV-COMP-${method^^}-R18-MNIST-A03-TOPK01-S${seed}"
  out="${ROOT}/${method}/seed${seed}"
  run_train "${name}" "${out}" --baseline "${method}" "${BASE_ARGS[@]}"
done

run_controlled_analysis "${ROOT}" "${ANALYSIS_BASE}/09_compressed_baselines_mnist_a03_n20_topk01"
run_comm_analysis "${ROOT}" "${ANALYSIS_BASE}/09_compressed_baselines_mnist_a03_n20_topk01/communication" 0.9
