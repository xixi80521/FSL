#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
preflight

# Reviewer purpose:
# repeated principal comparison for confidence intervals / paired analysis.
# Default reruns seeds 10,20,30 on the SAME frozen code. If seed10 is already
# verified from this exact code fingerprint, use: SEEDS="20 30" bash this_file
SEEDS_STR="${SEEDS:-10 20 30}"
read -r -a SEED_ARRAY <<< "${SEEDS_STR}"
ROOT="${LOG_BASE}/01_core_multiseed_mnist_a03_n20"

for seed in "${SEED_ARRAY[@]}"; do
  for method in dtfl epafl; do
    base_args mnist 0.3 20 1.0 "${ROUNDS:-200}" "${seed}"
    # First-hit efficiency requires per-round evaluation.
    set_arg BASE_ARGS --eval_every 1
    set_arg BASE_ARGS --eval_personalized_every 5
    name="REV-CORE-${method^^}-R18-MNIST-A03-N20-S${seed}"
    out="${ROOT}/${method}/seed${seed}"
    run_train "${name}" "${out}" --baseline "${method}" "${BASE_ARGS[@]}"
  done
done

run_controlled_analysis "${ROOT}" "${ANALYSIS_BASE}/01_core_multiseed_mnist_a03_n20"
