#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
preflight

# Reviewer purpose:
# N=100 server-state, scheduler, aggregation, tier-group, and queue diagnostics.
seed="${SEED:-10}"
ROOT="${LOG_BASE}/02_scalability_n100"
base_args mnist 0.8 100 1.0 "${ROUNDS:-50}" "${seed}"
set_arg BASE_ARGS --evaluation_mode none
set_arg BASE_ARGS --enable_personalized_test false
set_arg BASE_ARGS --enable_energy_profile false
set_arg BASE_ARGS --lr_patience 100000
name="REV-SCALE-EPAFL-R18-MNIST-A08-N100-S${seed}"
out="${ROOT}/seed${seed}"
run_train "${name}" "${out}" --baseline epafl "${BASE_ARGS[@]}"

run_controlled_analysis "${ROOT}" "${ANALYSIS_BASE}/02_scalability_n100"
