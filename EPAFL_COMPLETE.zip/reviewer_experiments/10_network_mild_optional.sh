#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
preflight

# Optional: mild stochastic bandwidth fluctuation.
seed="${SEED:-10}"
ROOT="${LOG_BASE}/10_network_mild_mnist_a03_n20"
base_args mnist 0.3 20 1.0 "${ROUNDS:-200}" "${seed}"
set_arg BASE_ARGS --bandwidth_trace fluctuating
set_arg BASE_ARGS --bw_jitter_sigma 0.10
set_arg BASE_ARGS --bw_congestion_prob 0.02
set_arg BASE_ARGS --bw_congestion_factor 8
set_arg BASE_ARGS --eval_every 1
run_train "REV-NET-EPAFL-R18-MNIST-A03-MILD-S${seed}" \
  "${ROOT}/seed${seed}" --baseline epafl "${BASE_ARGS[@]}"

run_controlled_analysis "${ROOT}" "${ANALYSIS_BASE}/10_network_mild_mnist_a03_n20"
