#!/usr/bin/env python3
import argparse, json, os, platform, sys

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.abspath(os.path.join(_THIS_DIR, ".."))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import torch
from utils.system_profile import SystemProfiler

p = argparse.ArgumentParser()
p.add_argument("--out", required=True)
a = p.parse_args()

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
prof = SystemProfiler(device)
snap = prof.snapshot()
payload = {
    "python": sys.version,
    "platform": platform.platform(),
    "torch": torch.__version__,
    "cuda_available": torch.cuda.is_available(),
    "cuda_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
    "profiler_available": prof.available,
    "snapshot": snap,
}
os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
with open(a.out, "w", encoding="utf-8") as f:
    json.dump(payload, f, indent=2, ensure_ascii=False, default=str)
print("[PREFLIGHT] profiler:", prof.available)
print("[PREFLIGHT] snapshot:", snap)
print("[PREFLIGHT] wrote:", os.path.abspath(a.out))
