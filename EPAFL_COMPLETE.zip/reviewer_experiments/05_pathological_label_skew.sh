#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
preflight

# Reviewer purpose: extreme missing-class/pathological label skew.
seed="${SEED:-10}"
ROOT="${LOG_BASE}/05_pathological_mnist_n20"
base_args mnist 0.1 20 1.0 "${ROUNDS:-200}" "${seed}"
set_arg BASE_ARGS --partition_method pathological
set_arg BASE_ARGS --shards_per_client 2
run_train "REV-HET-EPAFL-R18-MNIST-PATH2-N20-S${seed}" \
  "${ROOT}/seed${seed}" --baseline epafl "${BASE_ARGS[@]}"

run_controlled_analysis "${ROOT}" "${ANALYSIS_BASE}/05_pathological_mnist_n20"
